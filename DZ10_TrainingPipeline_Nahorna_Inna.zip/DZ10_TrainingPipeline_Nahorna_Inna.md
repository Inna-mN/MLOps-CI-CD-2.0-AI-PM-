
## Автоматизоване тренування моделей: контроль процесу, ризики та production-readiness

**Проєктний сценарій:** automated training pipeline для моделі прогнозування відтоку клієнтів `churn_prediction_v3`.

**Примітка щодо числових критеріїв**: наведені порогові значення quality gates є умовними та використовуються для демонстрації логіки automated training pipeline. Перед застосуванням у production їх необхідно підтвердити на основі бізнес-вимог, характеристик даних і результатів ML-експериментів.

---

## 1. High-level workflow automated training pipeline

### 1.1. Схема процесу

```text
GitLab event / manual trigger / schedule / drift alert
                         |
                         v
                GitLab CI pipeline
       (перевірка доступів, параметрів і Git-контексту)
                         |
                         v
          AWS Step Functions execution
                         |
                         v
                 Data validation
                         |
              успішно? -- ні --> Stop + notification
                         |
                        так
                         v
                   Training job
                         |
              успішно? -- ні --> Logs + notification
                         |
                        так
                         v
                  Model evaluation
             (метрики + baseline comparison)
                         |
                         v
              Logging metrics & artifacts
       (завжди: і для passed, і для відхилених)
                         |
                         v
                   Quality gates
                         |
             пройдено? -- ні --> Status: quality_gate_failed
                         |       (не реєструється; причина в MLflow)
                        так       
                         |                    |
                         v                    |
               Model Registry update          |                
                 (status: candidate)          |
                         |                    |
                         +---------+----------+
                                   v
                             Team notification
                                   |
                                   v
                         Staging validation
                                   |
                       успішно? -- ні --> Stop + notification
                                   |
                                  так
                                   v
                       Manual production approval
                                   |
                      approved? -- ні --> Remain candidate
                                   |
                                  так
                                   v
                          Production release
```

### 1.2. Ролі компонентів і логіка процесу

1. **GitLab event / manual trigger.** Pipeline запускається після merge у `main` для dev-сценарію, вручну для контрольованого retraining або за розкладом / сигналом drift для перевіреного процесу retraining. До запуску визначаються модель, середовище та причина запуску.
2. **GitLab CI.** Виконує початкові перевірки, отримує короткострокові AWS credentials через OIDC, передає в Step Functions параметри запуску та Git-контекст: `commit_sha`, `branch`, `source`, `model_name`, `environment`. GitLab CI також зберігає посилання на execution і повертає команді статус запуску.
3. **AWS Step Functions.** Оркеструє послідовність кроків: validation, training, evaluation, logging, реєстрацію моделі та notification. Керує залежностями між кроками, timeout, retry для тимчасових помилок і переходами до гілок failure.
4. **Data validation.** Перевіряє наявність датасету, схему, обов’язкові поля, типи, пропуски, допустимі діапазони та актуальність даних. Якщо критична перевірка не пройдена, тренування не запускається.
5. **Training job.** Запускає навчання на зафіксованій версії коду, даних і конфігурації. Для відтворюваності фіксуються версія датасету, commit SHA, параметри тренування та версія середовища.
6. **Model evaluation.** Обчислює ML-метрики та порівнює результат із baseline і поточною production-моделлю. Рішення за quality gates ухвалюється після логування результатів; якщо gates не пройдені, модель не просувається далі.
7. **Logging metrics and artifacts.** Логування виконується завжди - і для моделей, що пройшли gates, і для відхилених, щоб команда могла проаналізувати причину. Метрики, параметри, версії даних і коду, логи та артефакти експерименту записуються в MLflow Tracking. Артефакти зберігаються у визначеному сховищі, наприклад S3, із контрольованим доступом.
8. **Model Registry update.** Модель, яка пройшла автоматичні quality gates, реєструється в MLflow Model Registry зі статусом `candidate`. Реєстрація candidate не означає автоматичного дозволу на production.
9. **Notification to team.** AI/ML Engineer, MLOps Engineer, AI PM і Tech Lead отримують повідомлення про результат, ключові метрики, commit, посилання на execution та наступну дію. У разі помилки повідомлення надходить відповідальному owner-у.
10. **Staging validation** та **manual production approval.** Після реєстрації моделі як candidate команда перевіряє її роботу у staging. За результатами staging-перевірок AI PM і Tech Lead оцінюють ML-метрики, бізнес-ефект і ризики та ухвалюють рішення щодо production release. Якщо перевірки не пройдено або approval не отримано, модель не просувається до production.

**Розмежування відповідальності:** GitLab CI ініціює процес і передає контекст; Step Functions керує виконанням workflow; MLflow фіксує експеримент і модель; команда ухвалює рішення щодо release. Технічне завершення workflow саме по собі не є підтвердженням production-readiness.

---

## 2. Контрольні точки pipeline

| Етап pipeline | Що перевіряє команда | Owner | Що є успіхом | Дія у разі помилки |
|---|---|---|---|---|
| GitLab CI / запуск | Валідність параметрів, branch, commit SHA, source, environment та доступів | DevOps / MLOps Engineer | Step Functions отримав коректний input, execution створено | Зупинити запуск, перевірити CI job, IAM/OIDC та параметри; повідомити MLOps |
| Data validation | Наявність даних, схема, типи, обов’язкові поля, пропуски, діапазони, актуальність | Data Engineer | Усі критичні перевірки пройдено, датасет має версію | Зупинити pipeline; зафіксувати причину; Data Engineer виправляє дані або схему |
| Training job | Версії коду й даних, конфігурацію, ресурси, завершення job | AI/ML Engineer | Job завершився успішно, артефакт моделі створено | Перевірити логи та ресурси; повторити лише після усунення причини або створити incident |
| Model evaluation | ML-метрики, baseline, production-модель, стабільність на ключових сегментах | AI/ML Engineer | Усі встановлені threshold виконано | Встановити статус `quality_gate_failed`; не реєструвати та не просувати модель; проаналізувати причину за залогованими метриками |
| Logging metrics & artifacts | Повноту параметрів, метрик, артефактів, Git- і data-контексту | MLOps Engineer | MLflow run містить усі обов’язкові метадані й артефакти | Не реєструвати модель як candidate; перевірити tracking server і доступ до сховища |
| Model Registry | Наявність моделі, версію, lineage, метрики та статус | MLOps Engineer | Модель зареєстрована як `candidate` з посиланням на run | Перевірити права та логи registry; повторити реєстрацію без дублювання версій |
| Notification | Доставку повідомлення, статус, посилання, owner і наступну дію | MLOps Engineer; AI PM контролює зміст | Повідомлення доставлено потрібному каналу й містить достатній контекст | Повторити доставку, створити alert; статус execution залишається доступним у Step Functions |
| Approval / release readiness | Quality gates, бізнес-критерії, staging-перевірки та погодження | AI PM + Tech Lead | Є зафіксоване рішення `approved` для наступного середовища | Залишити модель у candidate/rejected; вказати причину та потрібні доопрацювання |

---

## 3. Quality gates для нової моделі

Quality gates мають перевіряти не лише факт успішного навчання, а й те, чи є модель достатньо якісною та безпечною для наступного етапу lifecycle.

Для прикладу `churn_prediction_v3` пропонуються такі стартові правила:

**Терміни статусів.** 
`quality_gate_failed` - результат автоматичної перевірки, який фіксується в метаданих MLflow run, якщо модель не пройшла quality gates. Це не стандартний технічний статус MLflow або AWS Step Functions. Технічно execution завершується зі статусом SUCCEEDED (усі кроки виконані), а GitLab CI job позначається як failed, щоб команда одразу бачила відхилення моделі. Модель із результатом quality_gate_failed не реєструється в Model Registry як candidate і не просувається до production, якщо немає документованого винятку (див. Baseline comparison).

`candidate`- модель у Model Registry, яка пройшла автоматичні quality gates, але ще не отримала manual approval.

`rejected` / `archived` - статуси або позначення рішень щодо відхилення моделі після аналізу чи manual approval. archived також може використовуватися для моделей, виведених з активного використання.

`approved` - зафіксоване рішення AI PM і Tech Lead про дозвіл на просування моделі до наступного середовища. Саме по собі це рішення не означає, що модель уже розгорнута в production.


| Quality gate | Правило / threshold | Хто перевіряє | Рішення |
|---|---|---|---|
| Data quality | Немає критичних помилок схеми; обов’язкові поля присутні; частка пропусків у критичних полях не перевищує погоджений ліміт (наприклад, 1%) | Data Engineer | Продовжити або зупинити pipeline |
| ML metric - F1-score | F1-score не нижче production baseline; цільове значення для прикладу - не менше 0.82 | AI/ML Engineer | Продовжити або `quality_gate_failed` |
| ML metric - Recall | Recall не нижче погодженого порога (наприклад, 0.78), оскільки пропуск клієнта з ризиком відтоку має бізнес-наслідки | AI/ML Engineer | Продовжити або `quality_gate_failed` |
| Baseline comparison | F1-score нової моделі не нижче поточної production-моделі; інші ключові метрики (наприклад, Precision) не повинні погіршуватися більше ніж на 2% відносно baseline. Абсолютні пороги F1 і Recall діють незалежно. Якщо встановлені пороги порушено, модель не проходить автоматичні quality gates. Винятковий дозвіл можливий лише після окремого документованого погодження AI PM і Tech Lead; у такому разі модель реєструється в Model Registry зі статусом `candidate` і позначкою `exception_approved`, а причина вказується в MLflow run. Це не означає автоматичного production release. | AI/ML Engineer | Продовжити або `quality_gate_failed` |
| Business metric / сегменти | На ключових сегментах клієнтів немає критичного погіршення; очікуваний бізнес-ефект не нижче погодженого мінімуму | AI PM + аналітик / бізнес-owner | Погодити або `rejected` |
| Reproducibility / logging | Збережені commit SHA, версія датасету, конфігурація, метрики та артефакти; експеримент можна відтворити | MLOps Engineer | Дозволити реєстрацію candidate або зупинити |
| Manual approval | AI PM і Tech Lead переглянули результати; для production також пройдені staging-перевірки | AI PM + Tech Lead | `approved` або `rejected` |
| Registry status | Лише модель, що пройшла автоматичні gates (або отримала документований виняток), може отримати `candidate`; `production` - тільки після окремого approval | MLOps Engineer | Зареєструвати candidate або не реєструвати модель (статус `quality_gate_failed` фіксується в MLflow run) |

**Правило порівняння.** Порівняння проводиться на однаковому контрольному наборі даних і за однаковою методикою обчислення метрик. Baseline - це поточна production-модель або заздалегідь зафіксована стабільна версія. Якщо метрики конфліктують (наприклад, F1 зростає, а Recall падає), рішення не можна приймати лише за однією метрикою: потрібно оцінити наслідки для бізнесу.

**Manual approval.** Автоматичне проходження threshold дозволяє зареєструвати модель як `candidate`, але не запускає production release. AI PM оцінює бізнес-критерії та ризики, Tech Lead підтверджує технічну готовність, а MLOps Engineer перевіряє коректність реєстрації та deployment-процесу.

**Якщо модель навчилась, але не пройшла gates:** результат перевірки фіксується як `quality_gate_failed` у метаданих MLflow run. Метрики й артефакти зберігаються для аналізу. Модель не реєструється в Model Registry як `candidate` (окрім випадку документованого винятку AI PM і Tech Lead), не отримує рішення `approved` і не просувається до production. Команда аналізує причини відхилення, визначає необхідні зміни в даних, ознаках або конфігурації та запускає новий run після виправлень.

---

## 4. Правила запуску training pipeline

| Trigger | Коли доречний | Перевага | Ризик | Рекомендоване середовище |
|---|---|---|---|---|
| Push / merge у `main` | Після merge змін у training code або pipeline config; для швидкої перевірки інтеграції | Раннє виявлення помилок, автоматизований feedback | Зайві дорогі training runs через зміни, які не впливають на модель | Dev; у staging - за правилами changed files |
| Manual trigger | Для контрольованого retraining, перевірки кандидата або запуску після виправлення проблем | Команда контролює момент запуску й параметри | Залежність від дисципліни команди; ризик затримки retraining | Staging / production |
| Schedule | Для регулярного retraining, наприклад раз на місяць, якщо дані регулярно оновлюються | Передбачуваність і регулярна перевірка актуальності моделі | Може запускатися без реальної потреби; зайві витрати | Staging; production - лише з gates та обмеженнями частоти |
| Drift / quality degradation signal | Коли monitoring виявив погоджений рівень data drift або падіння якості | Реакція на фактичну зміну даних чи якості | Хибні сигнали; retraining не усуне проблему, якщо причина в помилці даних або процесу | Production-сценарій як тригер для candidate training, не для автоматичного release |

### Рекомендована політика

- У **dev** запускати pipeline після merge змін у `main`, що стосуються training code, data validation або конфігурації. Для документації та нерелевантних змін повне тренування не потрібне.
- У **staging** використовувати manual trigger або schedule. Кожен запуск має створювати окремий execution із зафіксованими параметрами.
- У **production-контексті** manual trigger (за погодженням AI PM), drift-сигнал або schedule може ініціювати підготовку нового candidate. Автоматичне просування моделі в production заборонене.
- Для захисту від циклічних і надмірних запусків встановити мінімальний інтервал між retraining, ліміт паралельних executions і правила дедуплікації однакових запитів.
- Перед повторним запуском після failure визначати причину. Автоматичний retry застосовувати лише до тимчасових помилок інфраструктури, а не до помилок даних або quality gates.

---

## 5. Risk register

Оцінки ймовірності та впливу є якісними: Low - низькі, Medium - середні, High - високі.

| Ризик | Ймовірність | Вплив | Як зменшити ризик | Owner |
|---|---|---|---|---|
| GitLab CI має надмірні AWS-права або витік credentials | Medium | High | Використовувати OIDC замість довготривалих ключів; IAM least privilege; окремі ролі для dev/staging/prod; ротація й аудит доступів | DevOps / MLOps Engineer |
| Неправильний або невалідний датасет | Medium | High | Data validation до training; версіонування датасетів; контроль схеми, пропусків і діапазонів; зупинка при критичній помилці | Data Engineer |
| Training запускається занадто часто | High | Medium | Обмеження trigger-ів; schedule; rules by changed files; cooldown; ліміти паралельних executions | AI PM + MLOps Engineer |
| Неконтрольоване зростання AWS-витрат | Medium | High | Budget alerts; ліміти часу й ресурсів job; автоматичне завершення завислих executions; теги витрат за проєктом і середовищем; регулярний cost review | MLOps Engineer / FinOps |
| Training job завершується через нестачу ресурсів або timeout | Medium | Medium | Встановити timeout і resource limits; моніторити використання CPU/GPU/RAM; зберігати логи; retry лише для тимчасових помилок | AI/ML Engineer |
| Модель технічно навчилась, але не проходить quality gates | Medium | High | Baseline comparison; threshold для кількох метрик; перевірка ключових сегментів; заборона автоматичного release | AI/ML Engineer + AI PM |
| Метрики або артефакти не записалися в MLflow | Medium | High | Перевірка logging як окремий gate; контроль доступності tracking server і S3; повторна доставка логів; не реєструвати candidate без повного набору метаданих | MLOps Engineer |
| Помилкова або дубльована реєстрація моделі | Low | Medium | Ідемпотентна логіка реєстрації; унікальний run ID; перевірка lineage та статусу перед оновленням Registry | MLOps Engineer |
| Notification не доставлено або містить недостатньо контексту | Medium | Medium | Контроль доставки; повторна спроба; alert у резервний канал; посилання на execution і owner у кожному повідомленні | MLOps Engineer |
| Автоматичний release неякісної моделі | Low | High | Розділити `candidate` та `production`; manual approval AI PM і Tech Lead; окремий release gate; rollback-план | AI PM + Tech Lead |

### Ключові умови перед production

1. Доступ GitLab CI до AWS працює через OIDC і обмежений конкретними ролями та діями.
2. Для кожного execution можна відновити Git-, data- і model-контекст.
3. Витрати обмежені бюджетними alerts, timeout і ресурсними лімітами.
4. Помилки мають зрозумілі статуси, логи, owner-ів і процедуру повторного запуску.
5. Модель не може перейти в production без quality gates та зафіксованого approval.

---

## 6. Acceptance criteria для Jira-задачі

**Задача:** «Інтегрувати GitLab CI з AWS Step Functions для automated training pipeline».

Задачу можна вважати виконаною, якщо виконуються всі критерії:

- [ ] GitLab CI може ініціювати запуск визначеного AWS Step Functions state machine у дозволеному середовищі.
- [ ] У Step Functions input передаються `commit_sha`, `branch`, `source="gitlab-ci"`, `model_name` та `environment`.
- [ ] Для кожного запуску створюється окремий execution із доступним execution ID і статусом у AWS Console.
- [ ] У GitLab CI зберігається посилання або execution ID, за яким можна знайти відповідний запуск у AWS.
- [ ] GitLab CI job запускає execution, очікує його завершення (polling статусу) з обмеженим максимальним часом очікування і завершується статусом, що відповідає статусу execution (SUCCEEDED → success; FAILED / TIMED_OUT / ABORTED → failed). Якщо execution завершився SUCCEEDED, але в MLflow зафіксовано `quality_gate_failed`, GitLab job завершується статусом failed, а notification містить причину відхилення.
- [ ] Workflow містить окремий `DataValidation` step, який виконується до training job.
- [ ] Якщо data validation завершується помилкою, training job не запускається, а execution отримує зрозумілий failure status.
- [ ] Training job використовує зафіксовані версії коду, даних і конфігурації.
- [ ] Після training виконується evaluation із розрахунком щонайменше F1-score і Recall.
- [ ] Результати training та evaluation - параметри, метрики, логи й артефакти - записуються в MLflow або погоджену систему tracking незалежно від того, чи пройдені quality gates.
- [ ] У tracking-записі доступні commit SHA, версія датасету, конфігурація та ідентифікатор Step Functions execution.
- [ ] Quality gates автоматично порівнюють результати з baseline та перевіряють thresholds, зафіксовані в розділі 3 (F1 ≥ baseline і ≥ 0.82; Recall ≥ 0.78; допустиме відносне погіршення інших ключових метрик — не більше 2%).
- [ ] Якщо хоча б один обов'язковий threshold порушено, результат перевірки фіксується як quality_gate_failed у метаданих MLflow run із зазначенням причини. Модель не реєструється в Model Registry як candidate і не просувається до production. Виняток можливий лише за документованим погодженням AI PM і Tech Lead: тоді модель реєструється як `candidate` з позначкою `exception_approved`, що не означає дозволу на production release. Зміна затверджених thresholds також потребує окремого погодження.
- [ ] Якщо quality gates пройдені, модель реєструється в Model Registry зі статусом `candidate` і посиланням на відповідний training run.
- [ ] Production-реліз неможливий без окремого manual approval від визначених відповідальних осіб.
- [ ] Доступ GitLab CI до AWS налаштований за принципом least privilege; використовуються короткострокові credentials через OIDC, а довготривалі AWS access keys не зберігаються в CI variables.
- [ ] Для dev, staging і production використовуються окремі ролі або еквівалентні обмеження доступу.
- [ ] Для тимчасових помилок налаштовані контрольовані retry та timeout; для помилок даних і quality gates автоматичний безумовний retry не виконується.
- [ ] Команда отримує notification про success і failure із назвою pipeline, commit/branch, статусом, ключовими метриками або причиною помилки, посиланням на деталі, наступною дією та owner-ом.
- [ ] Успішний технічний execution не змінює production-модель автоматично.
- [ ] Є короткий runbook: де переглянути execution і логи, як визначити failed step, хто owner та за яких умов дозволено повторний запуск.

---

## 7. Notification messages

### 7.1. Успішне виконання

```text
✅ Training pipeline completed successfully

Pipeline: churn_prediction_training
Model: churn_prediction_v3
Environment: staging
Source: GitLab CI
Trigger: manual
Branch: main
Commit: 7f3a91c

Step Functions:
Execution: MLOpsTrainingPipeline / execution-2026-11-07-001
Status: SUCCEEDED

Evaluation:
F1-score: 0.84 (baseline: 0.81, threshold: 0.82)
Recall: 0.79 (baseline: 0.77, threshold: 0.78)
Data validation: PASSED
Automated quality gates: PASSED
Business review / manual approval: PENDING

Model Registry:
Model version: 3
Status: candidate
Production approval: NOT GRANTED (candidate ≠ production)

Details:
MLflow run: [посилання на MLflow run]
Step Functions: [посилання на execution]
GitLab pipeline: [посилання на GitLab pipeline]

Next action:
AI PM та Tech Lead перевіряють бізнес-критерії й погоджують
або відхиляють подальше просування моделі.
До рішення release у production заборонений.

Owner: AI PM
```

### 7.2. Помилка виконання

```text
❌ Training pipeline failed

Pipeline: churn_prediction_training
Model: churn_prediction_v3
Environment: staging
Source: GitLab CI
Trigger: manual
Branch: main
Commit: 7f3a91c

Step Functions:
Execution: MLOpsTrainingPipeline / execution-2026-11-07-002
Status: FAILED
Failed step: DataValidation

Reason:
Missing required column: customer_age
Dataset: customers_2026_11_07

Metrics: N/A - evaluation not executed (pipeline stopped at DataValidation)
Model Registry: not updated

Details:
Step Functions logs: [посилання на execution logs]
GitLab job logs: [посилання на GitLab job]
Validation report: [посилання на validation report]

Next action:
Data Engineer перевіряє джерело та схему датасету.
Після виправлення даних потрібно повторно запустити pipeline.
Автоматичне продовження training не виконується.

Owner: Data Engineer
```

**Принцип notification:** повідомлення має відповідати на чотири запитання: що сталося, де знайти деталі, що робити далі та хто відповідає. Для success воно також має чітко показувати, що `candidate` не дорівнює `production`.

---

## 8. Короткий висновок

Automated training pipeline є важливою частиною MLOps, оскільки робить тренування моделей відтворюваним, контрольованим і прозорим для команди. GitLab CI відповідає за ініціацію workflow, початкові перевірки та передачу Git-контексту, а AWS Step Functions оркеструє послідовність етапів і обробку помилок. MLflow забезпечує збереження метрик, параметрів, артефактів та інформації про модель. Водночас успішне завершення pipeline означає лише те, що технічні кроки виконалися, але не доводить готовність моделі до production. Для цього необхідні data validation, порівняння з baseline, виконання ML- і бізнес-критеріїв, перевірка staging та manual approval. Окремо потрібно контролювати AWS-доступи, витрати, частоту запусків і процедури відновлення після помилок. Отже, production-readiness - це спільне рішення AI/ML Engineer, MLOps Engineer, AI PM і Tech Lead, а не автоматичний наслідок успішного training run.
